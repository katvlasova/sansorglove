//Bluetooth portion of the code
// The serviceUuid must match the serviceUuid of the device you would like to connect
//"19B10000-E8F2-537E-4F6C-D104768A1216"
const serviceUuid = "2A5A20B9-0000-4B9C-9C69-4975713E0FF2";
let accelerationCharacteristic;
let gyroscopeCharacteristic;
let thumbCharacteristic;
let firstCharacteristic;
let secondCharacteristic;
let thirdCharacteristic;
let ax = 0, ay = 0, az = 0;
let gx = 0, gy = 0, gz = 0;
let myBLE;

//setting up the drawing array
points = [];
start = false;

//variables for drawing on the canvas
var xpos = 10;
var ypos = 10;
var xSpeed =1;
var ySpeed =1;
var objectType = "circle"; //circle, square or triangle
var thumbvalue;
var firstvalue;
var secondvalue;
var thirdvalue;
var shapeSize = 30;
var reds = 255;
var greens = 0;
var blues = 0;
var backgroundcolor = (255,255,255);

function setup() {
  createCanvas(windowWidth, windowHeight);
  textSize(20);
  textAlign(CENTER, CENTER);
  //background(backgroundcolor);
  
  // Create a p5ble class
  myBLE = new p5ble();

  // Create a 'Connect and Start Notifications' button
  const connectButton = createButton('Connect and Start Notifications')
  connectButton.mousePressed(connectAndStartNotify);
}

function connectAndStartNotify() {
  // Connect to a device by passing the service UUID
  myBLE.connect(serviceUuid, gotCharacteristics);
}

// A function that will be called once got characteristics
function gotCharacteristics(error, characteristics) {
  if (error) console.log('error: ', error);
  for (let i = 0; i < characteristics.length; i++) {
    if (i == 0) {
      accelerationCharacteristic = characteristics[i];
      // Set datatype to 'custom', p5.ble.js won't parse the data, will return data as it is.
      myBLE.startNotifications(accelerationCharacteristic, handleAcceleration, 'custom');
    } else if (i == 1) {
      gyroscopeCharacteristic = characteristics[i];
      myBLE.startNotifications(gyroscopeCharacteristic, handleGyroscope, 'custom');
    } else if (i == 2){
      thumbCharacteristic = characteristics[i];
      myBLE.startNotifications(thumbCharacteristic, handleThumb, 'custom');  
    }else if (i == 3){
      firstCharacteristic = characteristics[i];
      myBLE.startNotifications(firstCharacteristic, handleFirst, 'custom');
    }else if (i == 4){
      secondCharacteristic = characteristics[i];
      myBLE.startNotifications(secondCharacteristic, handleSecond, 'custom');
    }
    else if (i == 5){
      thirdCharacteristic = characteristics[i];
      myBLE.startNotifications(thirdCharacteristic, handleThird, 'custom');
    }
    else {
      console.log("characteristic doesn't match.");
    }
  }
}

// A function that will be called once got characteristics
function handleAcceleration(data) {
  ax = data.getFloat32(0, true);
  ay = data.getFloat32(4, true);
  az = data.getFloat32(8, true);
}

function handleGyroscope(data) {
  gx = data.getFloat32(0, true);
  gy = data.getFloat32(4, true);
  gz = data.getFloat32(8, true);
}

function handleThumb(data){
  thumbvalue = data.getInt8(0);
  console.log("thumb value:", thumbvalue);
}
function handleFirst(data){
  firstvalue = data.getInt8(0);
  console.log("first value:", firstvalue);
}
function handleSecond(data){
  secondvalue = data.getInt8(0);
  console.log("second value:", secondvalue);
}
function handleThird(data){
  thirdvalue = data.getInt8(0);
  console.log("third value:", thirdvalue);
}

function draw() {
  background(backgroundcolor);
  rectMode(CENTER);
  textSize(10);
  fill(reds,greens,blues);
  
  //reading my sensor values thru BT
  //accelerometer and gyroscope
//   text(`Acceleration X: ${ax}`, 200, 50);
//   text(`Acceleration Y: ${ay}`, 200, 70);
//   text(`Acceleration Z: ${az}`, 200, 90);

//   text(`Gyroscope X: ${gx}`, 200, 120);
//   text(`Gyroscope Y: ${gy}`, 200, 140);
//   text(`Gyroscope Z: ${gz}`, 200, 160);
  
//   text(`Thumb: ${thumbvalue}`,200, 200); 
//   text(`First: ${firstvalue}`,200, 220);
//   text(`Second: ${secondvalue}`,200, 240);
//   text(`Third: ${thirdvalue}`,200, 260);
  //position
  xpos = (windowWidth/2) - (gx+ xSpeed);
  ypos = (windowHeight/2) - (gy+ xSpeed);
  //xSpeed= ax;
  //ySpeed = ay;
  
    //checking if drawing line
  if(start){
    points.push(createVector(xpos, ypos));
  }
  stroke(255,0,0);
  
  //choosing what shape to draw
  beginShape();
  for (i= 0; i < points.length; i++){
    let x = points[i].x;
    let y = points[i].y;
    vertex(x, y);
  }
  endShape();
  
  if (objectType === "circle"){
    ellipse(xpos,ypos,shapeSize);
    for (i= 0; i < points.length; i++){
      let x = points[i].x;
      let y = points[i].y;
      ellipse(x,y,shapeSize);
    }
    
  }
  else if (objectType === "square"){
    square(xpos, ypos, shapeSize);
  }
  
  fingerInputs(); 
}

function fingerInputs(){ 
  //thumb to shape choice
  if (thumbvalue == 0){
    objectType = "circle";
  }
  else if(thumbvalue == 1){
    objectType = "square";
  }
  
  if (firstvalue === 1){
    reds = random(255);
    greens = random(255);
    blues = random(255);
    fill(reds, greens, blues);
  }
  //black or white bg depending on middle finger
  if(secondvalue == 1){
      backgroundcolor = (0,0,0);
  }
  else if(secondvalue == 0 ){
    backgroundcolor = (255,255,255);
  }
  
  
  //checking for fist - if user makes a fist, draw the lines
  if ( thumbvalue == 1 && firstvalue == 1 && secondvalue ==1){
    start = true;
  }
  else{
    start = false;
  }
  
  
}